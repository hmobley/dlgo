from dlgo.data.index_processor import KGSIndex

index = KGSIndex()
index.download_files()
